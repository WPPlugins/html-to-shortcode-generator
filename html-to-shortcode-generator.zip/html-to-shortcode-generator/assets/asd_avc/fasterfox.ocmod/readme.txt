﻿How to install 

step 1: Login in to Dashboard
step 2: Extensions -> Extension Installer
step 3: click upload and select file fasterfox.ocmod.zip and click Upload

